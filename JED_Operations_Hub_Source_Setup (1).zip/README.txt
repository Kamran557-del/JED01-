# JED Operations Hub — Setup Guide

## 1. What is this?
This is a simple static website made with:
- `index.html` = dashboard design/layout
- `links.js` = all Google Sheet names + links
- No database
- No server
- No paid software required

## 2. How to run it
Keep `index.html` and `links.js` in the SAME folder.
Double-click `index.html`.
It will open in Chrome/Edge.

## 3. How to change a Google Sheet link
Open `links.js` in Notepad.
Find the sheet you want.
Change only the value after:
url: "..."

Example:
url: "https://docs.google.com/spreadsheets/d/NEW_LINK/edit"

Save the file.
Refresh the dashboard.

## 4. How to add a new sheet
Copy one existing object in `links.js` and change:
- category: stock / zone / glass
- type: TRACKER / DAMAGE / ANALYSIS
- name
- description
- url

The dashboard card will appear automatically.

## 5. How the original dashboard was made
The visual style was recreated from the screenshot supplied in the chat.
The source code was written for this dashboard; it was not downloaded from a third-party template.

## 6. Important
The Google Sheet permissions are separate from the dashboard.
If a user does not have permission to open a Sheet, clicking the card will still open the Google URL but Google will ask for access.

## 7. Recommended next step
For a team-wide URL, upload this folder to GitHub Pages or another static hosting service.
